function toggleMode(){
    const html = document.documentElement
    html.classList.toggle("light")

    // if (html.classList.contains('light')) {
        
    // }else {
    //     html.classList.add('light')
    // }

    
}